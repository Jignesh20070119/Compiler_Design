%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* AST Node */
typedef struct Node
{
    char value[20];
    struct Node *left;
    struct Node *right;
} Node;

Node *root = NULL;

Node *createNode(const char *value, Node *left, Node *right);

void preorder(Node *root);
void inorder(Node *root);
void postorder(Node *root);
void printTree(Node *root, int level);

int yylex(void);
void yyerror(const char *s);
%}

/* Semantic value types */
%union
{
    Node *node;
    char *text;
}

/* Tokens */
%token <text> ID

/* Operator precedence */
%left '+'
%left '*'

%type <node> expr

%%

input:
    expr '\n'
    {
        root = $1;

        printf("\nAbstract Syntax Tree:\n");
        printTree(root, 0);

        printf("\nPreorder Traversal  : ");
        preorder(root);

        printf("\nInorder Traversal   : ");
        inorder(root);

        printf("\nPostorder Traversal : ");
        postorder(root);

        printf("\n");
    }
    ;

expr:
      expr '+' expr
    {
        $$ = createNode("+", $1, $3);
    }

    | expr '*' expr
    {
        $$ = createNode("*", $1, $3);
    }

    | ID
    {
        $$ = createNode($1, NULL, NULL);
        free($1);
    }
    ;

%%

/* Create a new AST node */
Node *createNode(const char *value, Node *left, Node *right)
{
    Node *newNode;

    newNode = (Node *)malloc(sizeof(Node));

    strcpy(newNode->value, value);

    newNode->left = left;
    newNode->right = right;

    return newNode;
}

/* Preorder: Root -> Left -> Right */
void preorder(Node *root)
{
    if (root == NULL)
        return;

    printf("%s ", root->value);

    preorder(root->left);
    preorder(root->right);
}

/* Inorder: Left -> Root -> Right */
void inorder(Node *root)
{
    if (root == NULL)
        return;

    inorder(root->left);

    printf("%s ", root->value);

    inorder(root->right);
}

/* Postorder: Left -> Right -> Root */
void postorder(Node *root)
{
    if (root == NULL)
        return;

    postorder(root->left);
    postorder(root->right);

    printf("%s ", root->value);
}

/* Display tree structure */
void printTree(Node *root, int level)
{
    int i;

    if (root == NULL)
        return;

    for (i = 0; i < level; i++)
        printf("    ");

    printf("%s\n", root->value);

    printTree(root->left, level + 1);
    printTree(root->right, level + 1);
}

/* Lexical analyzer */
int yylex(void)
{
    int c;
    char buffer[20];
    int i = 0;

    /* Ignore spaces and tabs */
    while ((c = getchar()) == ' ' || c == '\t')
        ;

    /* Identifier */
    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        c == '_')
    {
        do
        {
            if (i < 19)
                buffer[i++] = (char)c;

            c = getchar();

        } while ((c >= 'a' && c <= 'z') ||
                 (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') ||
                 c == '_');

        buffer[i] = '\0';

        ungetc(c, stdin);

        yylval.text =
            (char *)malloc(strlen(buffer) + 1);

        strcpy(yylval.text, buffer);

        return ID;
    }

    return c;
}

/* Error handling */
void yyerror(const char *s)
{
    printf("Syntax Error: %s\n", s);
}

/* Main function */
int main(void)
{
    printf("Enter arithmetic expression: ");

    yyparse();

    return 0;
}