%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TYPES 50
#define MAX_VARS 50

/* Type table */
typedef struct
{
    char name[20];
    char baseType[20];
} Type;

/* Variable table */
typedef struct
{
    char name[20];
    char type[20];
} Variable;

Type typeTable[MAX_TYPES];
Variable variableTable[MAX_VARS];

int typeCount = 0;
int variableCount = 0;

/* Function declarations */
void addType(char *name, char *baseType);
void addVariable(char *type, char *name);

const char *getBaseType(const char *type);

int nameEquivalent(const char *type1, const char *type2);
int structuralEquivalent(const char *type1, const char *type2);

const char *getVariableType(const char *name);

int yylex(void);
void yyerror(const char *s);
%}

%union
{
    char *str;
}

%token TYPE INT FLOAT
%token <str> ID
%token ASSIGN

%type <str> type_spec

%%

program:
    declarations
    {
        printf("\nAll declarations processed successfully.\n");
    }
    ;

declarations:
      declarations declaration
    | declaration
    ;

declaration:
      TYPE ID ASSIGN type_spec ';'
    {
        addType($2, $4);

        free($2);
        free($4);
    }

    | type_spec ID ';'
    {
        addVariable($1, $2);

        free($1);
        free($2);
    }

    | ID ID ';'
    {
        addVariable($1, $2);

        free($1);
        free($2);
    }
    ;

type_spec:
      INT
    {
        $$ = (char *)malloc(10);
        strcpy($$, "int");
    }

    | FLOAT
    {
        $$ = (char *)malloc(10);
        strcpy($$, "float");
    }
    ;

%%

/* Add user-defined type */
void addType(char *name, char *baseType)
{
    strcpy(typeTable[typeCount].name, name);
    strcpy(typeTable[typeCount].baseType, baseType);

    typeCount++;

    printf("Type declaration: %s = %s\n",
           name, baseType);
}

/* Add variable */
void addVariable(char *type, char *name)
{
    strcpy(variableTable[variableCount].name, name);
    strcpy(variableTable[variableCount].type, type);

    variableCount++;

    printf("Variable declaration: %s %s\n",
           type, name);
}

/* Find base type */
const char *getBaseType(const char *type)
{
    int i;

    /* Built-in types */
    if (strcmp(type, "int") == 0 ||
        strcmp(type, "float") == 0)
    {
        return type;
    }

    /* User-defined types */
    for (i = 0; i < typeCount; i++)
    {
        if (strcmp(typeTable[i].name, type) == 0)
        {
            return typeTable[i].baseType;
        }
    }

    return type;
}

/* Name equivalence */
int nameEquivalent(const char *type1,
                   const char *type2)
{
    if (strcmp(type1, type2) == 0)
        return 1;

    return 0;
}

/* Structural equivalence */
int structuralEquivalent(const char *type1,
                         const char *type2)
{
    const char *base1 = getBaseType(type1);
    const char *base2 = getBaseType(type2);

    if (strcmp(base1, base2) == 0)
        return 1;

    return 0;
}

/* Get type of variable */
const char *getVariableType(const char *name)
{
    int i;

    for (i = 0; i < variableCount; i++)
    {
        if (strcmp(variableTable[i].name, name) == 0)
        {
            return variableTable[i].type;
        }
    }

    return NULL;
}

/* Lexical analyzer */
int yylex(void)
{
    int c;

    char buffer[50];

    int i = 0;

    /* Ignore spaces, tabs and newlines */
    while ((c = getchar()) == ' ' ||
           c == '\t' ||
           c == '\n')
    {
    }

    if (c == EOF)
        return 0;

    /* Identifier / keyword */
    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        c == '_')
    {
        do
        {
            if (i < 49)
                buffer[i++] = (char)c;

            c = getchar();

        } while ((c >= 'a' && c <= 'z') ||
                 (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') ||
                 c == '_');

        buffer[i] = '\0';

        ungetc(c, stdin);

        /* Keywords */
        if (strcmp(buffer, "type") == 0)
            return TYPE;

        if (strcmp(buffer, "int") == 0)
            return INT;

        if (strcmp(buffer, "float") == 0)
            return FLOAT;

        /* Identifier */
        yylval.str =
            (char *)malloc(strlen(buffer) + 1);

        strcpy(yylval.str, buffer);

        return ID;
    }

    /* Assignment operator */
    if (c == '=')
        return ASSIGN;

    return c;
}

/* Error handling */
void yyerror(const char *s)
{
    printf("Syntax Error: %s\n", s);
}

/* Main */
int main(void)
{
    const char *typeX;
    const char *typeY;

    printf("Enter type and variable declarations:\n\n");

    printf("Example:\n");
    printf("type A = int;\n");
    printf("type B = int;\n");
    printf("A x;\n");
    printf("B y;\n\n");

    printf("Enter your declarations:\n");

    yyparse();

    /* Get types of x and y */
    typeX = getVariableType("x");
    typeY = getVariableType("y");

    printf("\n===== TYPE EQUIVALENCE ANALYSIS =====\n");

    if (typeX != NULL && typeY != NULL)
    {
        printf("Type of x = %s\n", typeX);
        printf("Type of y = %s\n", typeY);

        /* Name equivalence */
        if (nameEquivalent(typeX, typeY))
        {
            printf("\nName Equivalence       : Equivalent\n");
        }
        else
        {
            printf("\nName Equivalence       : Not Equivalent\n");
        }

        /* Structural equivalence */
        if (structuralEquivalent(typeX, typeY))
        {
            printf("Structural Equivalence : Equivalent\n");
        }
        else
        {
            printf("Structural Equivalence : Not Equivalent\n");
        }
    }
    else
    {
        printf("\nVariables x and y were not found.\n");
    }

    return 0;
}