%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);
void yyerror(const char *s);
%}

%token NUMBER

%left '+'
%left '*'

%%

input:
    expr '\n'
    {
        printf("\nFinal Synthesized Value = %d\n", $1);
    }
    ;

expr:
      expr '+' term
    {
        $$ = $1 + $3;

        printf("Reduction: expr -> expr + term\n");
        printf("           $1 = %d, $3 = %d, $$ = %d\n",
               $1, $3, $$);
    }

    | term
    {
        $$ = $1;

        printf("Reduction: expr -> term\n");
        printf("           $1 = %d, $$ = %d\n",
               $1, $$);
    }
    ;

term:
      term '*' factor
    {
        $$ = $1 * $3;

        printf("Reduction: term -> term * factor\n");
        printf("           $1 = %d, $3 = %d, $$ = %d\n",
               $1, $3, $$);
    }

    | factor
    {
        $$ = $1;

        printf("Reduction: term -> factor\n");
        printf("           $1 = %d, $$ = %d\n",
               $1, $$);
    }
    ;

factor:
    NUMBER
    {
        $$ = $1;

        printf("Reduction: factor -> NUMBER\n");
        printf("           $1 = %d, $$ = %d\n",
               $1, $$);
    }
    ;

%%

/* Lexical analyzer */
int yylex(void)
{
    int c;

    /* Ignore spaces and tabs */
    while ((c = getchar()) == ' ' || c == '\t')
        ;

    /* Read number */
    if (c >= '0' && c <= '9')
    {
        int value = 0;

        do
        {
            value = value * 10 + (c - '0');
            c = getchar();

        } while (c >= '0' && c <= '9');

        ungetc(c, stdin);

        yylval = value;

        return NUMBER;
    }

    return c;
}

/* Error handling */
void yyerror(const char *s)
{
    printf("Syntax Error: %s\n", s);
}

/* Main function */
int main(void)
{
    printf("Enter arithmetic expression: ");

    yyparse();

    return 0;
}