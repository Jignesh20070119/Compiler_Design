%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VARS 50

/* Symbol table entry */
typedef struct
{
    char name[30];
    char type[10];
} Variable;

Variable symbolTable[MAX_VARS];

int variableCount = 0;

/* Function declarations */
void addVariable(const char *type, const char *name);
const char *getType(const char *name);
void checkAssignment(const char *left, const char *right);

int yylex(void);
void yyerror(const char *s);
%}

%union
{
    char *str;
}

%token INT FLOAT
%token <str> ID

%%

program:
    declarations assignment
    ;

declarations:
      declarations declaration
    | declaration
    ;

declaration:
      FLOAT ID ';'
    {
        addVariable("float", $2);
        free($2);
    }

    | INT ID ';'
    {
        addVariable("int", $2);
        free($2);
    }
    ;

assignment:
    ID '=' ID ';'
    {
        checkAssignment($1, $3);

        free($1);
        free($3);
    }
    ;

%%

/* Add variable to symbol table */
void addVariable(const char *type, const char *name)
{
    strcpy(symbolTable[variableCount].name, name);
    strcpy(symbolTable[variableCount].type, type);

    variableCount++;

    printf("Declared: %s %s\n", type, name);
}

/* Find variable type */
const char *getType(const char *name)
{
    int i;

    for (i = 0; i < variableCount; i++)
    {
        if (strcmp(symbolTable[i].name, name) == 0)
        {
            return symbolTable[i].type;
        }
    }

    return NULL;
}

/* Check assignment and perform coercion */
void checkAssignment(const char *left,
                     const char *right)
{
    const char *leftType;
    const char *rightType;

    leftType = getType(left);
    rightType = getType(right);

    printf("\n===== ASSIGNMENT ANALYSIS =====\n");

    printf("Assignment: %s = %s\n", left, right);

    printf("Left-hand type  : %s\n",
           leftType ? leftType : "unknown");

    printf("Right-hand type : %s\n",
           rightType ? rightType : "unknown");

    if (leftType == NULL || rightType == NULL)
    {
        printf("\nType Error: Undeclared variable.\n");
        return;
    }

    /* Same types */
    if (strcmp(leftType, rightType) == 0)
    {
        printf("\nNo type conversion required.\n");
    }

    /* int -> float */
    else if (strcmp(leftType, "float") == 0 &&
             strcmp(rightType, "int") == 0)
    {
        printf("\nImplicit type conversion:\n");
        printf("int -> float\n");

        printf("The integer value of '%s' is promoted to float.\n",
               right);

        printf("Final type of '%s' = float\n",
               left);
    }

    /* float -> int */
    else if (strcmp(leftType, "int") == 0 &&
             strcmp(rightType, "float") == 0)
    {
        printf("\nWarning: float -> int conversion.\n");
        printf("Possible loss of fractional information.\n");
    }

    else
    {
        printf("\nType Error: Incompatible types.\n");
    }
}

/* Lexical analyzer */
int yylex(void)
{
    int c;

    char buffer[50];

    int i = 0;

    /* Ignore spaces, tabs and newlines */
    while ((c = getchar()) == ' ' ||
           c == '\t' ||
           c == '\n')
    {
    }

    if (c == EOF)
        return 0;

    /* Identifier / keyword */
    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        c == '_')
    {
        do
        {
            if (i < 49)
                buffer[i++] = (char)c;

            c = getchar();

        } while ((c >= 'a' && c <= 'z') ||
                 (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') ||
                 c == '_');

        buffer[i] = '\0';

        ungetc(c, stdin);

        /* Keywords */
        if (strcmp(buffer, "int") == 0)
            return INT;

        if (strcmp(buffer, "float") == 0)
            return FLOAT;

        /* Identifier */
        yylval.str =
            (char *)malloc(strlen(buffer) + 1);

        strcpy(yylval.str, buffer);

        return ID;
    }

    return c;
}

/* Error handling */
void yyerror(const char *s)
{
    printf("Syntax Error: %s\n", s);
}

/* Main */
int main(void)
{
    printf("Enter program fragment:\n\n");

    printf("Example:\n");
    printf("float temperature;\n");
    printf("int sensor_value;\n");
    printf("temperature = sensor_value;\n\n");

    yyparse();

    printf("\n===== FINAL TYPE INFORMATION =====\n");

    printf("temperature : float\n");
    printf("sensor_value: int\n");

    return 0;
}